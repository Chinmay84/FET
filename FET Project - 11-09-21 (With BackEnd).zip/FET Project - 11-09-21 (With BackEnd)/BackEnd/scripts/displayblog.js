

var onClickfordisplay=()=>{

    $.ajax({
        type: 'GET',
        contentType: 'application/json',
        url: "http://localhost:3000/blogs",
        dataType: "json",
        success: (result)=>{
          if(result!=null){

            const { userid,category,title,imgpath,text,timestamp,likes,comments,id}=result[0];

              let para=document.getElementById("p1");
              let element;
              for(let i=0;i<result.length;i++)
              {
                element+=`<div class="card" id=${id}>
                <img class="img-fluid" alt="100%x280"
                  src="${imgpath}">
                <div class="card-body">
                  <h4 class="card-title">Music</h4>
                  <button type="button" class="btn btn-warning"><a href="create.html"
                      style="color: black;">Read</a></button>
                </div>
              </div>`
              }
              para.innerHTML=element;
          }
        }

    })
}
