const onClickforcomment=(id,event)=>{

    event.preventDefault();
    $.ajax({


        

})

}
