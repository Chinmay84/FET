var onClickforlike=(id,event)=>{
    event.preventDefault();
    $.ajax({
        type: 'GET',
        contentType: 'application/json',
        url: `http://localhost:3000/blogs?id=${id}`,
        dataType: "json",
        success: (result)=>{
          if(result[0]!=null){
            console.log(result[0]);
            const { userid,category,title,imgpath,text,timestamp,likes,comments}=result[0];
            let obj={
                userid:userid,
                category:category,
                title:title,
                imgpath:imgpath,
                text:text,
                timestamp:timestamp,
                likes:likes+1,
                comments:comments,
                id:id
            }
            console.log(obj);
            $.ajax({
                url: `http://localhost:3000/blogs/${id}`,
                type: 'PUT',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify(obj),
                success: function (data, textStatus, xhr) {
                    console.log(data);
                },
                error: function (xhr, textStatus, errorThrown) {
                    console.log('Error in Operation');
                }
            });


          }
        }

    })


}
