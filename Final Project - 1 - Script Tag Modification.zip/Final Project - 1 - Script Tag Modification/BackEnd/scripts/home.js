    var display = () => {   //Need to declare display as var because display is initialized multipled times
        var isLogin = sessionStorage.getItem("userid");//jquery session not working
        if (isLogin) {
            $("#login").css("display","none");
            $("#signup").css("display","none");

        } else {
            $("#create").css("display","none");
            $("#logout").css("display","none");
        }
    };
    const sessionClear = document.querySelector("#logout");
    sessionClear.addEventListener("click", function () {
        sessionStorage.clear();
        window.location.replace("home.html");
    });


