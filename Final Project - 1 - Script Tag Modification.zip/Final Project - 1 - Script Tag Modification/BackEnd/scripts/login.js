
let onClickforlogin=()=>{
    var email=$("#username").val();
    var password=$("#password").val();

    $.ajax({
        type: 'GET',
        contentType: 'application/json',
        url: `http://localhost:3000/users?userName=${email}`,
        dataType: "json",
        success: (result)=>{

            if(result[0]!=null){
                console.log(result[0].password);
                if(result[0].password === password)
                {
                    alert("Login successful");
                    sessionStorage.setItem("userid",result[0].id);
                    window.location.href = "../../FrontEnd/html/home.html";
                }else{
                    console.log("error")
                }
            }else{
                alert("User does not exits");
            }
        },
        error: (xhr, status, error) => {
            const errorMessage = xhr.status + ": " + xhr.statusText;
            alert("Error - " + errorMessage);
        }

    })


}


