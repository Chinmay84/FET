var formRef=$("#sign-form").val();
var nameRef = $("#name").val();
var passwordRef = $("#password").val();
var confPasswordRef = $("#confPassword").val();
var userName = $("#emailId").val();
const handleOnBlur = (inTag) => {
    if (inTag.value === "") {
        inTag.style.borderColor = "red";
    }
    if (inTag.value !== "") {
        inTag.style.borderColor = "inherit";
    }
}

const handleOnClick = (inTag, event) => {
    handleOnBlur(inTag);

    if (
        nameRef.value != "" &&
        passwordRef.value != "" &&
        userName.value != ""
    ) {
        var paswd = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/; //password between 7 to 15 characters which contain at least one numeric digit and a special character

        if (passwordRef.value == confPasswordRef.value) {
            if (paswd.test(passwordRef.value) && passwordRef.value != null) {
                const user = {
                    name: nameRef.value,
                    userName: userName.value,
                    password: passwordRef.value,
                };

                $.ajax({
                    type: "GET",
                    url: `http://localhost:3000/users?userName=${userName.value}`,
                    contentType: "application/json",
                    dataType: "json",
                    success: (response) => {
                        console.log(response);
                        if (response[0] == null) {
                            $.ajax({
                                type: "POST",
                                url: "http://localhost:3000/users",
                                contentType: "application/json",
                                dataType: "json",
                                data: JSON.stringify(user),
                                success: function (data) {
                                    if (data != null) {
                                        alert("Registered Successfully");
                                        $(location).attr('href', '../../FrontEnd/html/login.html');
                                    } else alert("post not complete");
                                },
                                error: (xhr, status, error) => {
                                    const errorMessage = xhr.status + ": " + xhr.statusText;
                                    alert("Error - " + errorMessage);
                                }
                            });
                        } else {
                            alert("Blank");
                        }
                    },
                    error: (xhr, status, error) => {
                        const errorMessage = xhr.status + ": " + xhr.statusText;
                        alert("Error - " + errorMessage);
                    }
                });
            } else {
                alert(
                    "Password between 7 to 15 characters which contain at least one numeric digit and a special character or EmailID must contain @ and ."
                );
            }
        } else {
            alert("password mismatch");
        }
    } else {
        alert("All field required");
    }
};
