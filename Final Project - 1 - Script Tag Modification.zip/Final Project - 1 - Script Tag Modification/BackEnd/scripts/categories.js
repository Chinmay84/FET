var dispCont = document.querySelector("#displayContainer");
var isLoggedIn = sessionStorage.getItem("userid") != null ? isLoggedIn = true : isLoggedIn = false;

$("button").on("click", (event) => {
    event.target.value === "all" ? displayPosts("*") : displayPosts("=" + event.target.value);
})

const displayPosts = (categoryType) => {
    let uri = "http://localhost:3000/blogs?category" + categoryType;
    $.ajax({
        url: uri,
        type: 'GET',
        contentType: 'application/json',
        dataType: "json",
        success: (blogs) => {
            let template = "";
            blogs.forEach((blog) => {
                template += displayBlog(blog);
            });
            dispCont.innerHTML = template;
        },
        error: (xhr, status, error) => {
            const errorMessage =
                xhr.status + ": " + xhr.statusText;
            alert("Error - " + errorMessage);
        }

    })
}


let displayBlog = (blog) => {

    let temp;
    let {category, title, imgpath, likes, id} = blog;
    if (isLoggedIn !== true) {
        temp = "#";
    } else {
        temp = "displayBlog.html?id=" + id;
    }
    console.log(blog);


    return (`
            <div class="container-fluid blogs2">
            <div class="row">
              <div class="col-md-3">
                <div class="col-sm-12"><img class="blogImg" src="${imgpath}" width="250px" height="250px"/></div>
              </div>
              <div class="col-md-9">
                <div class="col-sm-12"><h4>Title:${title}</h4></div>
                <div class="col-sm-12"><h4>Category:${category}</h4></div>
                <div class="catButton">
                    <button type="button" class="btn btn-outline-dark ">
                       <a href="${temp}" class="read">Read the Blog</a>
                    </button>
                </div><br>
                <div>
                <i class="fa fa-thumbs-up icon"><p class="fa-likes">${likes}</p></i>
                </div>
              </div>
            </div>
          </div>
    </div>`);
}


window.addEventListener("DOMContentLoaded", () => displayPosts("all"));
