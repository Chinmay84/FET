const bId = new URLSearchParams(window.location.search).get("id");
const container = document.querySelector(".more");

const renderDetails = () => {
    let uri = "http://localhost:3000/blogs?id=" + bId;
    $.ajax({
        url: uri,
        type: 'GET',
        contentType: 'application/json',
        dataType: "json",
        success: (blogs) => {
            let {title, imgpath, text, likes, id} = blogs[0];

            let template = `
    <div class="container-fluid">
      <h3>Title:${title}</h3>
      <div>
      <h3>Image:</h3>
      <div class="col-sm-12"><img class="blogImg" src="${imgpath}" width="250px" height="250px"/></div>
      </div>
      <h3>Blog Text:</h3><textarea class="blogText" disabled>${text}</textarea>
      <div>
            <i id="${id}" class="fa fa-thumbs-up icon" onclick="onClickforlike(this,this.id,event)"><p class="fa-likes">${likes}</p></i>
      <div>
      <button class="btn btn-dark" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
      Comment
      </button>
      <div class="collapse" id="collapseExample">
      <textarea class="blogText2" id="txtcomment"></textarea>
      <div>
      <button class="btn btn-dark" type="button" id="${id}" onclick="addComment('${id}')">

      Post
      </button></div>
      </div>
      </div>
      </div>
      <div class="comment"><button class="btn btn-outline-dark" onclick="displayComments('${id}')">Show all comments</button></div>
      <div class="overflow-auto" id="allcomments"></div> `;

            container.innerHTML = template;
        },
        error: (xhr, status, error) => {
            const errorMessage =
                xhr.status + ": " + xhr.statusText;
            alert("Error - " + errorMessage);
        }
    })

}

window.addEventListener("DOMContentLoaded", () => {
    renderDetails();
});
