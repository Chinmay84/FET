const searchBoxRef = document.getElementById("searchBox");
const dispResultRef = document.getElementById("dispResult")

searchBoxRef.addEventListener("keyup", async (e) => {
    let uri = "http://localhost:3000/"; //Endpoint for the GET Request
    uri = uri + "blogs";
    const res = await fetch(uri);  // waits till its gets all data from the server and the response is stored in
    // the const res; since we used fetch we get a response Object and not just data
    const blogs = await res.json(); // .json() parses the data in res (response object) and converts it to JS Object
    //from JSON, wait first and then store all the data in the post
    var template = "";
    blogs.forEach(blog => {
      /*  if(blog.title.match(searchBoxRef.value))
        {
            console.log("I'm here");
        }*/
     /*   if (blog.title === searchBoxRef.value) {
            console.log(blog.title + "I got clicked")
            template = template + `
        <div>
            <h2>${blog.title}</h2>
            <p>${blog.text}</p>
            <p>${blog.likes}</p>
            <p>${blog.category}</p>
        </div>`
        }*/
        var title = blog.title.toLowerCase();
        var search = searchBoxRef.value.toLowerCase();
        if (title.match(search)) {
            console.log(blog.title + "I got clicked")
            template = template + `
        <div>
            <h2>${blog.title}</h2>
        </div>`
        }
    })

    dispResultRef.innerHTML = template;
})


/*
var display=()=>{
    var isLogin=sessionStorage.getItem("userid");
    $(document).ready(()=>{
        $("#nav").hide();
        if(isLogin!=null){
            $("#createblog").hide();
            $("#logout").hide();
        }else{
            $("#login").hide();
            $("#signup").hide();

        }


})
}
*/
