var onClickfordisplay = () => {
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: "http://localhost:3000/blogs",
        dataType: "json",
        success: (result) => {
            if (result != null) {
                const {
                    userid,
                    category,
                    title,
                    imgpath,
                    text,
                    timestamp,
                    likes,
                    comments,
                    id,
                } = result[0];

                let para = document.getElementById("p1");
                let element;
                for (let i = 0; i < result.length; i++) {
                    //         element += `<div class="blogs" id=${id}>
                    //     <div><img src="${imgpath}"><div>
                    //     <div><h3>${title}</h3></div>
                    //     <div><h3>${category} </h3></div>
                    //     <div><button type="button" class="btn btn-outline-dark">Read the Blog</button></div>
                    //     <div><p>${likes}</p></div>
                    //   </div>`;
                    element += `<div class="container-fluid blogs2" id=${result[i].id}>
            <div class="row">
              <div class="col-md-3">
                <div class="col-sm-12"><img class="" src="${result[i].imgpath}" /></div>
              </div>
              <div class="col-md-9">
                <div class="col-sm-12"><h4>Title:${result[i].title}</h4></div>
                <div class="col-sm-12"><h4>Category:${result[i].category}</h4></div>
                <div>
                    <button type="button" class="btn btn-outline-dark">
                        Read the Blog
                    </button>
                </div>
              </div>
            </div>
          </div>
    </div>`;
                }
                para.innerHTML = element;
            }
        },
    });
};
