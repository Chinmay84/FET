const id= new URLSearchParams(window.location.search).get('id');
const container = document.querySelector(".more");

$(document).ready(function(){
    $.ajax({
        url:"http://localhost:3000/blogs/" + id ,
        dataType: 'json',
        type: 'get',
        cache:false,
        success: function(blogs){
            /*console.log(data);*/
            if(blogs.flag==true){
                console.log(blogs.id);
                var template =`
                <div class="container-fluid">
                  <h3>Title:${blogs.title}</h3>
                  <div>
                  <h3>Image:</h3>
                  <div class="col-sm-12"><img class="blogImg" src="${blogs.imgpath}" width="250px"; height="250px"/></div>
                  </div>
                  <h3>Blog Text:</h3><textarea class="blogText" disabled>${blogs.text}</textarea>
                  <div><h5>Likes:&nbsp;${blogs.likes}</h5></div>
                  <div>
                  <button class="btn btn-dark" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                  Comment
                  </button>
                  <div class="collapse" id="collapseExample">
                  <textarea class="blogText2" id="txtcomment"></textarea>
                  <div>
                  <button class="btn btn-dark" type="button" id="${blogs.id}" onclick="addcomment(${blogs.id})">
                  Post
                  </button></div>
                  </div>
                  </div>
                  </div>
                  <button onclick="displaycomment(${blogs.id})">Show all comments</button>
                  <div id="allcomments"></div>
                `}
                else{
                    var template = `
                    <div class="container-fluid">
                    <h3>Title:${blogs.title}</h3>
                    <div>
                    <h3>Blog Text:</h3><textarea class="blogText" disabled >${blogs.text}</textarea>
                    <div><h5>Likes:&nbsp;${blogs.likes}</h5></div>
                    </div>
                    <div>
                    <button class="btn btn-dark" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                    Comment
                    </button>
                    <div class="collapse" id="collapseExample">
                    <textarea class="blogText2" id="txtcomment"></textarea>
                    <div>
                    <button class="btn btn-dark" type="button" id="${blogs.id}" onclick="addcomment(${blogs.id})">
                    Post
                    </button></div>
                    </div>
                    </div>
                    </div>
                    <button onclick="displaycomment(${blogs.id})">Show all comments</button>
                    <div id="allcomments"></div>
                  `
                }
            $(".more").append(template);
        },
        error: function(d){
            /*console.log("error");*/
            alert("404. Please wait until the File is Loaded.");
        }
    });
});