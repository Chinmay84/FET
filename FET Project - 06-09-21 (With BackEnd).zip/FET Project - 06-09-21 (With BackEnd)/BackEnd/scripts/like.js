var onClickforlike=(element,id,event)=>{
    console.log("in");
    $.ajax({
        type: 'GET',
        contentType: 'application/json',
        url: `http://localhost:3000/blogs?id=${id}`,
        dataType: "json",
        success: (result)=>{
        console.log("in get");
          if(result[0]!=null){
            console.log(result[0]);
            const { userid,category,title,imgpath,text,timestamp,likes,comments,flag}=result[0];
            let obj={
                userid:userid,
                category:category,
                title:title,
                imgpath:imgpath,
                text:text,
                timestamp:timestamp,
                likes:likes+1,
                comments:comments,
                flag:flag,
                id:id,
            }
            console.log(obj);
            if(sessionStorage.getItem("userid")!=null){
            console.log("in put");
            element.style.color="blue";
            $.ajax({
                url: `http://localhost:3000/blogs/${id}`,
                type: 'PUT',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify(obj),
                success: function (data, textStatus, xhr) {
                    console.log(data);
                },
                error: function (xhr, textStatus, errorThrown) {
                    console.log('Error in Operation');
                }
            });
        }
          }
        }

    })
}
const getlikecount=()=>{
}
